package com.example.client_fx;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.Border;
import javafx.scene.paint.Color;

import java.net.URL;
import java.util.ResourceBundle;

/**
 * classe permettant d'interagir avec l'interface graphique 'fxml'
 */
public class HelloController implements Initializable {

    @FXML
    private TableView<Course> ListeCours;
    @FXML
    private TableColumn<Course, String> CodeCours;
    @FXML
    private TableColumn<Course, String> NomCours;

    @FXML
    private ComboBox<String> Sessions;

    @FXML
    private TextField Prenom;
    @FXML
    private TextField Nom;
    @FXML
    private TextField Email;
    @FXML
    private TextField Matricule;

    /**
     * objet qui permet d'afficher les différentes erreurs liées à l'utilisation de l'application
     */
    Alert alertErreur = new Alert(Alert.AlertType.ERROR, "");

    /**
     * objet qui permet d'afficher les différentes informations liées aux actions de l'utilisateur
     */
    Alert alertInfos = new Alert(Alert.AlertType.INFORMATION, "");

    /**
     * liste contenant les trois différentes sessions à afficher
     */
    ObservableList<String> observableList = FXCollections.observableArrayList(
            "Automne",
            "Ete",
            "Hiver"
    );

    /**
     * liste devant contenir les différents cours à afficher
     */
    ObservableList<Course> courses = FXCollections.observableArrayList(
    );

    /**
     * méthode permettant de charger la liste des cours lorque l'utilisateur appuis sur le bouton charger
     * Elle commence par vérifier si l'utilisateur a bien sélectionner la session dans la liste contenant les session et termine le precessus s'il ne l'a pas fait.
     * Si l'utilisateur a choisi une session elle appel la méthode 'F1' de la classe 'Client' chargée de recupérer la liste des cours auprès du serveur
     */
    @FXML
    public void Charger()
    {
        if (Sessions.getValue() == null)
        {
            alertErreur.setContentText("Veuillez choisir une session s'il vous plait");
            alertErreur.showAndWait();
            return;
        }
        else {
            courses.clear();
            courses.addAll(Client.F1(Sessions.getValue()));

            ListeCours.setItems(courses);
        }
    }

    /**
     * cette méthode permet de demarrer une inscription suite à un appuis sur le bouton envoyer de l'interface fx.
     * elle commence par effecuter un controle de saisie grace à la méthode 'ControleSaisie' pour s'assurer que tous les champs sont valides.
     * si les champs ne sont pas valide le processus s'arrête.
     * si les champs sont valides elle récupère la valeur de chaque champs dans des variables
     * puis s'assure que l'utilisateur a également sélectionner un des cours chargé dans l'interface.
     * Si aucun cour n'est sélectionner on envoi un message d'erreur demandant à l'utilisateur de choisir un cours.
     * dans le cas contraire on envoie les différentes information au serveur avec l'appel de la méthode 'F2' de la classe 'Client'.
     * on récupère et affiche ensuite le réponse du serveur renvoyée par cette dernière méthode.
     */
    @FXML
    public void Inscription()
    {
        if (!ControleSaisie())
        {
            this.alertErreur.showAndWait();
            return;
        }

        String Prenom = this.Prenom.getText();
        String Nom = this.Nom.getText();
        String Email = this.Email.getText();
        String Matricule = this.Matricule.getText();


        if (ListeCours.getSelectionModel().getSelectedItem() != null)
        {
            Course course = ListeCours.getSelectionModel().getSelectedItem();
            Object[] Reponse = Client.F2(Sessions.getValue(), course.getCode(), Matricule, Prenom, Nom, Email);
            System.out.println((boolean) Reponse[1]);
            if ((boolean) Reponse[1])
            {
                alertInfos.setContentText("Félicitation !\n" +
                        Prenom + " " + Nom + " à été inscrit(e) pour le cours " + course.getName());
                alertInfos.showAndWait();
            }
            else
            {
                alertErreur.setContentText(Reponse[0].toString());
                alertErreur.showAndWait();
            }
        }
        else
        {
            alertErreur.setContentText("Désolé ! \nVous devez sélectionner un cours d'abord");
            alertErreur.showAndWait();
        }
    }

    /**
     * initialisation de la liste des session dans l'interface graphique.
     * formatage de l'affichage des objets Course dans le tableau devant afficher la liste des cours chargée
     * @param url ...
     * @param resourceBundle ...
     */
    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Sessions.setItems(observableList);

        CodeCours.setCellValueFactory(new PropertyValueFactory<>("code"));
        NomCours.setCellValueFactory(new PropertyValueFactory<>("name"));
    }

    /**
     * effectu un contorle de saisi de tours les champs et récupère un message s'il ya des erreur dans un champs.
     * change la valeur du message d'erreur si jamais il ya des erreur
     *
     * @return on retourne 'true' si aucune erreur et 'false' dans le cas contraire
     */
    public boolean ControleSaisie()
    {
        this.alertErreur.setContentText("");
        boolean isCorrect = true;

        if (this.Prenom.getText().equals(""))
        {
            this.alertErreur.setContentText(this.alertErreur.getContentText() + "Le champ 'Prenom' est obligatoire\n");

            this.Prenom.setBorder(Border.stroke(Color.RED));
            isCorrect = false;
        }
        else
        {
            this.Prenom.setBorder(new TextField().getBorder());
        }

        if (this.Nom.getText().equals(""))
        {
            this.alertErreur.setContentText(this.alertErreur.getContentText() + "Le champ 'Nom' est obligatoire\n");

            this.Nom.setBorder(Border.stroke(Color.RED));
            isCorrect = false;
        }
        else
        {
            this.Nom.setBorder(new TextField().getBorder());
        }

        if(!this.Email.getText().contains("@") || !this.Email.getText().contains("."))
        {
            this.alertErreur.setContentText(this.alertErreur.getContentText() + "L'adresse mail que vous avez saisie est invalide\n");

            this.Email.setBorder(Border.stroke(Color.RED));
            isCorrect = false;
        }
        else
        {
            this.Email.setBorder(new TextField().getBorder());
        }

        if(this.Matricule.getText().length() < 6 || this.Matricule.getText().length() > 6)
        {
            this.alertErreur.setContentText(this.alertErreur.getContentText() + "Le Matricule que vous avez saisie doit invalide (6 Chiffres)");

            this.Matricule.setBorder(Border.stroke(Color.RED));
            isCorrect = false;
        }
        else
        {
            this.Matricule.setBorder(new TextField().getBorder());
        }
        return isCorrect;
    }
}