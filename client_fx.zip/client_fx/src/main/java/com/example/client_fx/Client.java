package com.example.client_fx;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Collection;
import java.util.Vector;

/**
 * la classe 'Client' permet de se connecter à un serveur, et de communiquer avec ce dernier
 */
public class Client {

    /**
     * C'est la commande permettant d'initialiser une inscription
     */
    public final static String REGISTER_COMMAND = "INSCRIRE";
    /**
     * Commande permettant de demander la liste des cours pour une session au serveur
     */
    public final static String LOAD_COMMAND = "CHARGER";
    private static Socket serveur;
    private static ObjectInputStream objectInputStream;
    private static ObjectOutputStream objectOutputStream;

    /**
     * cette fonction utilise l'adresse et le port du serveur fournis en paramètre pour établir une connexion au serveur
     * grace au constructeur de la classe 'Socket'
     * puis initialise les deux flux d'entrée et sortie 'objectInputStream' et 'objectInputStream'
     * @param Adresse Contient l'adresse qui permet de joindre le serveur
     * @param Port c'est le port par lequel le serveur est accessible
     */
    public static void Connexion(String Adresse, int Port)
    {
        try {
            serveur = new Socket(Adresse, Port);
            objectOutputStream = new ObjectOutputStream(serveur.getOutputStream());
            objectInputStream = new ObjectInputStream(serveur.getInputStream());

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * la méthode 'F1' établie une nouvelle connexion avec le serveur grâce a la méthode 'Connexion'.
     * puis grace au flux de sortie 'objectOutputStream elle envoie la commande qui permet de charger la liste des cours
     * ainsi que la session pour laquelle il souhaite obtenir la liste.
     * ensuite récupère grace à l'objet 'objectInputStream' la réponse du serveur et retourne le resultat sous forme de liste
     * @param Session c'est la session pour laquelle le client souhaite obtenir la liste des cours
     * @return retourne la liste des cours pour la session choisie
     */
    public static Vector<Course> F1(String Session)
    {
        Connexion("localhost", 1337);

        Vector<Course> courses = new Vector<>();
        try {
            //Envoie de la commande pour recevoir la liste des cours
            objectOutputStream.writeObject(LOAD_COMMAND + " "+ Session);

            try {
                //Reception de la liste des cours
                Vector<String> CoursListe = (Vector<String>) objectInputStream.readObject();

                for (int i = 0; i < CoursListe.size(); i++)
                {
                    courses.add(new Course(CoursListe.get(i).split("\t")[1], CoursListe.get(i).split("\t")[0], null));
                }

            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return courses;
    }

    /**
     * la méthode 'F1' établie une nouvelle connexion avec le serveur grâce a la méthode 'Connexion'.
     * puis grace au flux de sortie 'objectOutputStream elle envoie la commande qui permet d'initialiser une inscription.
     * ensuite elle utilise le même flux pour envoyer les informations nécessaire pour l'inscription.
     * Enfin elle recupère et retourne la reponse du serveur suite a cette inscription grace à l'objet 'objectInputStream'.
     *
     *  @param Session session choisie pour l'inscription
     * @param CodeCours code du cour choisi
     * @param Matricule matricule de l'étudiant souhaitant s'inscrire pour le cours
     * @param Prenom prénom de l'étudiant concerné
     * @param Nom nom de l'étudiant concerné
     * @param Email adresse email de l'étudiant concerné
     * @return la reponse du serveur suite à la demande d'inscription
     */
    public static Object[] F2(String Session, String CodeCours, String Matricule, String Prenom, String Nom, String Email)
    {
        Connexion("localhost", 1337);

        String [] objects = new String[]{Session, CodeCours, Matricule, Prenom, Nom, Email};
        try {
            //Envoie de la commande pour pour l'inscription
            objectOutputStream.writeObject(REGISTER_COMMAND + " ");

            //Envoie des données d'inscription
            objectOutputStream.writeObject(objects);

            try {
                //Reception de la Notification
                return (Object[]) objectInputStream.readObject();

            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }

        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
