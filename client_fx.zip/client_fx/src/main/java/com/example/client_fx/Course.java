package com.example.client_fx;

import java.io.Serializable;

public class Course implements Serializable {

    private String name;
    private String code;
    private String session;

    /**
     * constructeur qui instancie un objet cours
     *
     * @param name nom du cours
     * @param code code du cours
     * @param session session pendant laquelle a lieu le cours
     */
    public Course(String name, String code, String session) {
        this.name = name;
        this.code = code;
        this.session = session;
    }

    /**
     * @return renvoi le nom du cours
     */
    public String getName() {
        return name;
    }

    /**
     * change le nom du cours
     * @param name nouveau nom pour le cours
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     *
     * @return renvoie le code du cours
     */
    public String getCode() {
        return code;
    }

    /**
     * change le code du cours
     * @param code nouveau code du cours
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     *
     * @return retoune la session du cours
     */
    public String getSession() {
        return session;
    }

    /**
     * permet de modifier la session du cours
     * @param session nouvelle session du cours
     */
    public void setSession(String session) {
        this.session = session;
    }

    /**
     * permet de convertir l'objet en chaine de caractère pour pouvoir l'afficher en console
     * @return objet converti en chaine de caractère
     */
    @Override
    public String toString() {
        return "Course{" +
                "name=" + name +
                ", code=" + code +
                ", session=" + session +
                '}';
    }
}
